Self-hosted assets when using 'assets' option. Read more:
https://www.files.gallery/docs/self-hosted-assets/
https://www.files.gallery/docs/config/#assets